import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-main-content',
  templateUrl: './main-content.component.html',
  styleUrls: ['./main-content.component.scss']
})
export class MainContentComponent {
  // interpolation
  public name = 'Swapnil Hogade...';

  // ng model 2 way binding
  public yourName = '';

  // calculator
  // constructor for toaster
  constructor(private toastr: ToastrService) {}

  public num1: any;
  public num2: any;
  public result: any;

  add() {
    this.result = this.num1 + this.num2
    this.toastr.success("Addition is "+this.result)
  }
  sub() {
    this.result = this.num1 - this.num2
    this.toastr.info("substraction of number is "+this.result)
  }
  mul() {
    this.result = this.num1 * this.num2
    this.toastr.warning("mutiplication of a number"+this.result)
  }
  div() {
    this.result = this.num1 / this.num2
    this.toastr.success("division of number is"+this.result)
  }


}
