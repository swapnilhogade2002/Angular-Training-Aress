import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllRouteComponent } from './all-route.component';

describe('AllRouteComponent', () => {
  let component: AllRouteComponent;
  let fixture: ComponentFixture<AllRouteComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AllRouteComponent]
    });
    fixture = TestBed.createComponent(AllRouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
