import { Component } from '@angular/core';
import { NgModule } from '@angular/core';

@Component({
  selector: 'app-all-route',
  templateUrl: './all-route.component.html',
  styleUrls: ['./all-route.component.scss']
})
export class AllRouteComponent {

}
