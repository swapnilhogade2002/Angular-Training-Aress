import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SideBarComponent } from './side-bar/side-bar.component';
import { MainContentComponent } from './main-content/main-content.component';
import { FormsModule } from '@angular/forms';
import { ParentComponentComponent } from './parent-component/parent-component.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // Required for animations
import { ToastrModule } from 'ngx-toastr';
import { AboutComponent } from './about/about.component';
import { PipeDemoPipe } from './pipe/pipe-demo.pipe';
import { AllRouteComponent } from './all-route/all-route.component';
import { FooterComponent } from './footer/footer.component'; // Import the ToastrModule

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SideBarComponent,
    MainContentComponent,
    ParentComponentComponent,
    AboutComponent,
    PipeDemoPipe,
    AllRouteComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule, // Add BrowserAnimationsModule
    ToastrModule.forRoot() // Add ToastrModule with global configuration
  ],
  providers: [],
  bootstrap: [ParentComponentComponent]
})
export class AppModule { }
