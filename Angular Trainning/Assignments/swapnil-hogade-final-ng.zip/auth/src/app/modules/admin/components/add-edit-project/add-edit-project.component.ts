import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ProjectService } from '../project-service/project.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-edit-project',
  templateUrl: './add-edit-project.component.html',
  styleUrls: ['./add-edit-project.component.scss']
})
export class AddEditProjectComponent {
  @Input() project: any;
  @Output() close = new EventEmitter();
   
  // not allowing past date
  public currentDate: Date=new Date()

  public projectForm = new FormGroup({
    projectName: new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3), Validators.pattern(/^[^\d]+$/)]),
    projectStartDate: new FormControl("", [Validators.required]),
    projectEndDate: new FormControl("", [Validators.required]),
    fullName: new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3), Validators.pattern(/^[^\d]+$/)]),
    city: new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3), Validators.pattern(/^[^\d]+$/)]),
    age: new FormControl("", [Validators.required, Validators.min(0), Validators.max(100)]),
    experience: new FormControl("", [Validators.required, Validators.min(0), Validators.max(50)]),
    manager: new FormControl("", [Validators.required]),
    number: new FormControl("", [Validators.required, Validators.pattern(/^\d{10}$/), Validators.maxLength(10)]),
  });

  constructor(private teacherService: ProjectService, private toastrService: ToastrService) { }

  ngOnInit() {
    if (this.project) {
      this.projectForm.patchValue(this.project)
    }
  }

  onClose(): void {
    this.close.emit();
  }

  public save(): void {
    let payload = this.assignValueToModel();
    if (!this.project) {
      this.addProject(payload)
    }
    else {
      this.updateProject(payload)
    }

  }
  private addProject(payload: any): any {
    this.teacherService.addProject(payload).subscribe((response: any) => {
      this.toastrService.success("Teacher added succesfully", "Success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("error adding Teacher values", error)
      console.log(error)
    })
  }

  private updateProject(payload: any): any {
    this.teacherService.updateProject(payload).subscribe((response: any) => {
      this.toastrService.success("Teacher updated succesfully", "Success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("error updating Teacher values", error)
      console.log(error)
    })
  }

  private assignValueToModel(): any {
    let project = {
      "id": this.project ? this.project.id : 0,
      "projectName": this.projectForm.get("projectName")?.value,
      "projectStartDate": this.projectForm.get("projectStartDate")?.value,
      "projectEndDate": this.projectForm.get("projectEndDate")?.value,
      "fullName": this.projectForm.get("fullName")?.value,
      "city": this.projectForm.get("city")?.value,
      "age": this.projectForm.get("age")?.value,
      "experience": this.projectForm.get("experience")?.value,
      "manager": this.projectForm.get("manager")?.value,
      "number": this.projectForm.get("number")?.value,

    };
    return project;
  }

  public checkIfControlValid(controlName: string): any {
    return this.projectForm.get(controlName)?.invalid &&
      this.projectForm.get(controlName)?.errors &&
      (this.projectForm.get(controlName)?.dirty || this.projectForm.get(controlName)?.touched);
  }

  public checkControlHasError(controlName: string, error: string): any {
    return this.projectForm.get(controlName)?.hasError(error);
  }
}


