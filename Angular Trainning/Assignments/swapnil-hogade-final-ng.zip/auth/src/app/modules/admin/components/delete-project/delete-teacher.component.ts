import { Component } from '@angular/core';
import { EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-delete-project',
  templateUrl: './delete-project.component.html'
})
export class DeleteProjectComponent {
  @Output() close = new EventEmitter();
  @Output() confirmedDelete = new EventEmitter();

  public onClose(): void {
    this.close.emit();
  }

  public deleteInformation(): void {
    this.confirmedDelete.emit();
  }
}
