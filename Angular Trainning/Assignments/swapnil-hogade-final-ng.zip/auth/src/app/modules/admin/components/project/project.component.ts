import { Component } from '@angular/core';
import { AddEditProjectComponent } from '../add-edit-project/add-edit-project.component';
import { ToastrService } from 'ngx-toastr';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { DeleteProjectComponent } from '../delete-project/delete-teacher.component';
import { ProjectService } from '../project-service/project.service';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss']
})
export class ProjectComponent {
  public totalCount: number = 0;
  public projects: any[] = [];

  public addEditProjectModal!: BsModalRef;
  public deleteProjectModal!: BsModalRef;
  constructor(private projectService: ProjectService,
    private toastrService: ToastrService,
    private modalService: BsModalService
  ) { }

  ngOnInit() {
    this.loadProject();
  }

  private loadProject(): void {
    this.projectService.getProject().subscribe((response: any) => {
      this.projects = response;
      this.totalCount = this.projects.length;
      this.toastrService.success("project List loaded successfully", "Success");
    }, (error: any) => {
      this.toastrService.error("Error loading project list", "Error");
    })
  }

  public openAddEditProjectModal(teacher: any = null): void {
    this.addEditProjectModal = this.modalService.show(AddEditProjectComponent, {
      initialState: { project: teacher }, class: 'modal-lg',
      ignoreBackdropClick: true
    });

    this.addEditProjectModal.content.close.subscribe(() => {
      this.addEditProjectModal.hide();
      this.loadProject();
    });
  }

  // delete
  public openDeleteProjectModal(student: any): void {
    this.deleteProjectModal = this.modalService.show(DeleteProjectComponent, {
      class: 'modal-sm',
      ignoreBackdropClick: true
    });

    this.deleteProjectModal.content.close.subscribe(() => {
      this.deleteProjectModal.hide();
    });

    this.deleteProjectModal.content.confirmedDelete.subscribe(() => {
      debugger
      this.projectService.deleteProject(student.id).subscribe((response: any) => {
        this.toastrService.success('project deleted successfully', 'Success');
      }, (error: any) => {
        this.toastrService.error('Error deleting project', 'Error');
      });
      this.deleteProjectModal.hide();
      this.loadProject();
    });
  }
}
