import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

// get , post , put method for editing.
export class ProjectService {

  constructor(private httpClient: HttpClient) { }
  public getProject(): any {
    return this.httpClient.get(`http://localhost:8000/project`)
  }

  public addProject(project: any): any {
    return this.httpClient.post(`http://localhost:8000/project`, project)
  }

  public updateProject(project: any): any {
    return this.httpClient.put(`http://localhost:8000/project/${project.id}`, project)
  }

  public deleteProject(project: any): any {
    return this.httpClient.delete(`http://localhost:8000/project/${project}`)
  }

}
