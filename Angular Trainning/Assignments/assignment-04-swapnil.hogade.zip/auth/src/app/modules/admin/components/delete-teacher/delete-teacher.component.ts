import { Component } from '@angular/core';
import { EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-delete-teacher',
  templateUrl: './delete-teacher.component.html'
})
export class DeleteTeacherComponent {
  @Output() close = new EventEmitter();
  @Output() confirmedDelete = new EventEmitter();

  public onClose(): void {
    this.close.emit();
  }

  public deleteInformation(): void {
    this.confirmedDelete.emit();
  }
}
