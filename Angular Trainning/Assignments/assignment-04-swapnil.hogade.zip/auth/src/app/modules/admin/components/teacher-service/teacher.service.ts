import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TeacherService {

  constructor(private httpClient: HttpClient) { }
  public getTeachers(): any {
    return this.httpClient.get(`http://localhost:8000/teachers`)
  }

  public addTeachers(teacher: any): any {
    return this.httpClient.post(`http://localhost:8000/teachers`, teacher)
  }

  public updateTeachers(teacher: any): any {
    return this.httpClient.put(`http://localhost:8000/teachers/${teacher.id}`, teacher)
  }

  public deleteTeacher(teacher: any): any {
    return this.httpClient.delete(`http://localhost:8000/teachers/${teacher}`)
  }


}
