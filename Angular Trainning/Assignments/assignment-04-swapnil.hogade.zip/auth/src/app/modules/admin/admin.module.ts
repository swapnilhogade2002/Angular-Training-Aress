import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { ServicesComponent } from './components/services/services.component';
import { ContactComponent } from './components/contact/contact.component';
import { TeacherComponent } from './components/teacher/teacher.component';
import { AddEditTeacherComponent } from './components/add-edit-teacher/add-edit-teacher.component';
import { DeleteTeacherComponent } from './components/delete-teacher/delete-teacher.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { TeacherService } from './components/teacher-service/teacher.service';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AdminDashboardComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AboutComponent,
    ServicesComponent,
    ContactComponent,
    TeacherComponent,
    AddEditTeacherComponent,
    DeleteTeacherComponent
  ],
  providers: [TeacherService],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxDatatableModule,
    FormsModule,
  ]

})
export class AdminModule { }
