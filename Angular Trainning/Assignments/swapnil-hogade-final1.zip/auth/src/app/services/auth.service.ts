import { Observable, of, throwError } from 'rxjs';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';
import { ProjectService } from '../modules/admin/components/project-service/project.service';

@Injectable({
  providedIn: 'root',
})

// verification of username password and authentication.
export class AuthService {
  public data: any = [];
  constructor(private router: Router, private toastr: ToastrService, public service: ProjectService, private httpClient: HttpClient) { }

  setToken(token: string): void {
    localStorage.setItem('token', token);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  isLoggedIn() {
    return this.getToken() !== null;
  }

  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['login']);
  }

}
