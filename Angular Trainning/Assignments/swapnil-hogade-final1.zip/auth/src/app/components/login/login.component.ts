import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { ProjectService } from 'src/app/modules/admin/components/project-service/project.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})

export class LoginComponent implements OnInit {
  loginForm = new FormGroup({
    email: new FormControl(''),
    password: new FormControl(''),
  });

  constructor(private auth: AuthService, private router: Router, private toaster: ToastrService, private service: ProjectService) { }

  ngOnInit(): void {
    if (this.auth.isLoggedIn()) {
      this.router.navigate(['admin']);
    }
  }
  // login form validation method
  public login(): void {
    let email: any = this.loginForm.get('email')?.value;
    let password: any = this.loginForm.get('password')?.value;
    this.service.getUser().subscribe(
      (response: any[]) => {
        let userIndex = response.findIndex((user) => user.email.toLowerCase() === email?.toLowerCase() && user.password === password);
        if (userIndex !== -1) {
          localStorage.setItem("email", email?.toLowerCase());
          this.auth.setToken('email');
          this.toaster.success('User logged in successfully', 'Success');
          this.router.navigate(['/admin']);
        } else {
          this.toaster.error('Invalid Email or Password', 'Error');
        }
      },
      (error: any) => {
        this.toaster.error('Error in loading users list', 'Error');
      }
    );
  }
}
