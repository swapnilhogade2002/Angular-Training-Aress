import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TeacherService } from '../teacher.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-edit-teacher',
  templateUrl: './add-edit-teacher.component.html',
})

export class AddEditTeacherComponent {
  @Input() teacher: any;
  @Output() close = new EventEmitter();
  
  // form validation
  public teacherForm = new FormGroup({
    firstName: new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3), Validators.pattern(/^[^\d]+$/), Validators.pattern('[A-Za-z]+$')]),
    lastName: new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3), Validators.pattern(/^[^\d]+$/)],),
    city: new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3), Validators.pattern(/^[^\d]+$/)]),
    age: new FormControl("", [Validators.required, Validators.min(0), Validators.max(100)]),
    experience: new FormControl("", [Validators.required, Validators.min(0), Validators.max(50)]),
    gender: new FormControl("", [Validators.required]),
    number: new FormControl("", [Validators.required, Validators.pattern(/^\d{10}$/), Validators.maxLength(10)]),

  });

  constructor(private teacherService: TeacherService, private toastrService: ToastrService) { }

  ngOnInit() {
    if (this.teacher) {
      this.teacherForm.patchValue(this.teacher)
    }
  }

  onClose(): void {
    this.close.emit();
  }

  public save(): void {
    let payload = this.assignValueToModel();
    if (!this.teacher) {
      this.addTeacher(payload)
    }
    else {
      this.updateTeacher(payload)
    }
  }
  
  private addTeacher(payload: any): any {
    this.teacherService.addTeachers(payload).subscribe((response: any) => {
      this.toastrService.success("Teacher added succesfully", "Success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("error adding Teacher values", error)
      console.log(error)
    })
  }

  private updateTeacher(payload: any): any {
    this.teacherService.updateTeachers(payload).subscribe((response: any) => {
      this.toastrService.success("Teacher updated succesfully", "Success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("error updating Teacher values", error)
      console.log(error)
    })
  }

  private assignValueToModel(): any {
    let student = {
      "id": this.teacher ? this.teacher.id : 0,
      "firstName": this.teacherForm.get("firstName")?.value,
      "lastName": this.teacherForm.get("lastName")?.value,
      "city": this.teacherForm.get("city")?.value,
      "age": this.teacherForm.get("age")?.value,
      "experience": this.teacherForm.get("experience")?.value,
      "gender": this.teacherForm.get("gender")?.value,
      "number": this.teacherForm.get("number")?.value,
    };
    return student;
  }

  public checkIfControlValid(controlName: string): any {
    return this.teacherForm.get(controlName)?.invalid &&
      this.teacherForm.get(controlName)?.errors &&
      (this.teacherForm.get(controlName)?.dirty || this.teacherForm.get(controlName)?.touched);
  }

  public checkControlHasError(controlName: string, error: string): any {
    return this.teacherForm.get(controlName)?.hasError(error);
  }
}