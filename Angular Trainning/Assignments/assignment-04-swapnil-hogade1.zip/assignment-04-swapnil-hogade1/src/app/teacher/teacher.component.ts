import { Component } from '@angular/core';
import { TeacherService } from '../teacher.service';
import { AddEditTeacherComponent } from '../add-edit-teacher/add-edit-teacher.component';
import { ToastrService } from 'ngx-toastr';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { DeleteTeacherComponent } from '../delete-teacher/delete-teacher.component';

@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.scss']
})
export class TeacherComponent {
  public totalCount: number = 0;
  public teachers: any[] = [];

  public addEditTeacherModal!: BsModalRef;
  public deleteStudentModal!: BsModalRef;
  constructor(private teacherService: TeacherService,
    private toastrService: ToastrService,
    private modalService: BsModalService
  ) { }

  ngOnInit() {
    this.loadTeachers();
  }

  private loadTeachers(): void {
    this.teacherService.getTeachers().subscribe((response: any) => {
      this.teachers = response;
      this.totalCount = this.teachers.length;
      this.toastrService.success("Teachers List loaded successfully", "Success");
    }, (error: any) => {
      this.toastrService.error("Error loading teachers list", "Error");
    })
  }

  public openAddEditTeacherModal(teacher: any = null): void {
    this.addEditTeacherModal = this.modalService.show(AddEditTeacherComponent, {
      initialState: { teacher: teacher }, class: 'modal-lg',
      ignoreBackdropClick: true
    });

    this.addEditTeacherModal.content.close.subscribe(() => {
      this.addEditTeacherModal.hide();
      this.loadTeachers();
    });
  }

  // delete
  public openDeleteStudentModal(student: any): void {
    this.deleteStudentModal = this.modalService.show(DeleteTeacherComponent, {
      class: 'modal-sm',
      ignoreBackdropClick: true
    });

    this.deleteStudentModal.content.close.subscribe(() => {
      this.deleteStudentModal.hide();
    });

    this.deleteStudentModal.content.confirmedDelete.subscribe(() => {
      debugger
      this.teacherService.deleteTeacher(student.id).subscribe((response: any) => {
        this.toastrService.success('student deleted successfully', 'Success');
      }, (error: any) => {
        this.toastrService.error('Error deleting student', 'Error');
      });
      this.deleteStudentModal.hide();
      this.loadTeachers();
    });
  }
}
