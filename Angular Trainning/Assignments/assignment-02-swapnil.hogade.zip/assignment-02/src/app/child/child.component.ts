import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent {


  @Output() public childEvent = new EventEmitter();
  FireEvent() {
    this.childEvent.emit("Hii swapnil");
  }
  @Input() public parentData: any;

}
