import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  title = 'assignment-01';
  // child to parent
  public city="nashik";

  // parent to child
  public message="";

  // lifecycle hooks
  public ngOnChanges(  ): void {
    console.log("ngOnChanges");
  }

  public ngOnInit(): void {
    console.log("ngOnInit");
  }

  public ngDoCheck(): void {
    console.log("ngDoCheck");
  }

  public ngAfterContentInit(): void {
    console.log("ngAfterContentInit");
  }

  public ngAfterContentChecked(): void {
    console.log("ngAfterContentChecked");
  }

  public ngAfterViewInit(): void {
    console.log("ngAfterViewInit");
  }

  public ngAfterViewChecked(): void {
    console.log("ngAfterViewChecked");
  }

  public ngOnDestroy(): void {
    console.log("ngOnDestroy");
  }
}
