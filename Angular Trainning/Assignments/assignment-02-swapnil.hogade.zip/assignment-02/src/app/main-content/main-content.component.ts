import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-main-content',
  templateUrl: './main-content.component.html',
  styleUrls: ['./main-content.component.scss']
})
export class MainContentComponent {
  // interpolation
  public name = 'Swapnil Hogade...';

  // ng model 2 way binding
  public yourName = '';

  // calculator
  public num1: any;
  public num2: any;
  public result: any;

  add() {
    alert(this.result = this.num1 + this.num2)
  }

  sub() {
    alert(this.result = this.num1 - this.num2)
  }
  mul() {
    alert(this.result = this.num1 * this.num2)
  }
  div() {
    alert(this.result = this.num1 / this.num2)
  }

  // parent to child
  @Input() public parentData: any;

  // child to parent
  @Output() public childEvent = new EventEmitter();
  fireEvent() {
    this.childEvent.emit()
  }

  // child  to parent
  public message1 = "";
  public name1 = "swapnil";

}
